from http import server
from optparse import Option
import discord, datetime
from discord.ui import Button, View, Select
from discord.ext.commands import has_permissions, MissingPermissions, bot
from discord.ext import commands
from discord.ext.commands import MissingPermissions
import discord, datetime
from discord.ext.commands import Bot
from discord.ext import commands
import random
import nextcord, datetime
import os
from nextcord import Interaction, SlashOption, ChannelType, User
from datetime import datetime
from nextcord.abc import GuildChannel
from nextcord.ext import commands
from nextcord.ui import Select, View, Button
import asyncio
from requests import get
import aiohttp
import io


client = commands.Bot(command_prefix = "!")

serverID = 805379039924846613

@client.event
async def on_ready():
    print('Connected to bot: {}'.format(client.user.name))
    print('Bot ID: {}'.format(client.user.id))


responses = ["As I see it, yes.", "Ask again later.", "Better not tell you now.", "Cannot predict now.", "Concentrate and ask again.",
             "Don’t count on it.", "It is certain.", "It is decidedly so.", "Most likely.", "My reply is no.", "My sources say no.",
             "Outlook not so good.", "Outlook good.", "Reply hazy, try again.", "Signs point to yes.", "Very doubtful.", "Without a doubt.",
             "Yes.", "Yes – definitely.", "You may rely on it."]

dadjokes = ["I'm afraid for the calendar. Its days are numbered.", "Why do fathers take an extra pair of socks when they go golfing? In case they get a hole in one!", "Singing in the shower is fun until you get soap in your mouth. Then it's a soap opera.", "What do you call a factory that makes okay products? A satisfactory.", "Have you heard about the chocolate record player? It sounds pretty sweet.",
             "I only know 25 letters of the alphabet. I don't know y.", "Dad, can you put my shoes on? No, I don't think they'll fit me.", "What time did the man go to the dentist? Tooth hurt-y.", "A guy walks into a bar...and he was disqualified from the limbo contest.", "Shout out to my fingers. I can count on all of them.", "I have a joke about chemistry, but I don't think it will get a reaction.",
             "Outlook not so good.", "Outlook good.", "Reply hazy, try again.", "Signs point to yes.", "Very doubtful.", "Without a doubt.",
             "I thought the dryer was shrinking my clothes. Turns out it was the refrigerator all along.", "How does the moon cut his hair? Eclipse it.", "What concert costs just 45 cents? 50 Cent featuring Nickelback!"]


@client.slash_command(name = 'staffdmnotify', description='This sends selected user an DM.', guild_ids=[serverID])
async def staffdmnotify(interaction: Interaction, user:User, staff:bool, message:str):
    if interaction.user.guild_permissions.administrator == True:
        if staff == True:
            embedVar = discord.Embed(title="Staff Notification Recieved", description=(f'Hi there,\nThis is a automatic Text Message recieved from Staff:\n\n> **{message}**\n\n- **<@{interaction.user.id}>**'), color=0x00B6FF)
            await user.send(embed=embedVar)
            await interaction.response.defer(ephemeral = True)
            await asyncio.sleep(0)
            embedVar = discord.Embed(title="Staff Notification Sent", description=(f'You have sent an Notification to:\n> **<@{user.id}>**\n\nNotification Sender:\n> **<@{interaction.user.id}>**\n\nMessage Sent:\n> **{message}**'), color=0x00B6FF)
            await interaction.followup.send(embed=embedVar)
        else:
            if staff == False:
                embedVar = discord.Embed(title="Staff Notification Recieved", description=(f'Hi there,\nThis is a automatic Text Message recieved from Staff:\n\n> **{message}**\n\n- **Staff Team**'), color=0x00B6FF)
                await user.send(embed=embedVar)
                await interaction.response.defer(ephemeral = True)
                await asyncio.sleep(0)
                embedVar = discord.Embed(title="Staff Notification Sent", description=(f'You have sent an Notification to:\n> **<@{user.id}>**\n\nNotification Sender:\n> **<@{interaction.user.id}>**\n\nMessage Sent:\n> **{message}**'), color=0x00B6FF)
                await interaction.followup.send(embed=embedVar)
    else:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="Error!", description=(f'You do not have a permission to do this command.'), color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)



@client.slash_command(name = 'nuke', description=f'Nuke Server.', guild_ids=[serverID])
async def nuke(ctx, reason=None):
    categ=discord.utils.get(ctx.guild.categories,name="😎》 important")
    channel=await categ.create_text_channel(name=f"💣 NUKE 💣"topic=f"{ctx.user.id}")

    noreasonticketopened = discord.Embed(title=f"**Nuke Started!**", description=f"The nuke will happen in 30 minutes.", timestamp=datetime.now(), color=discord.Color.random())
    await ctx.send(embed=noreasonticketopened)
        
        
class Report(nextcord.ui.Modal):
    def __init__(self):
        super().__init__("Report User")  # Modal title

        # Create a text input and add it to the modal
        self.emTitle1 = nextcord.ui.TextInput(label = "User To Report (Discord Username)", min_length = 2, max_length = 124, required = True, placeholder = "Enter username of person to report here.")
        self.add_item(self.emTitle1)

        self.emTitle2 = nextcord.ui.TextInput(label = "User To Report (Roblox Username)", min_length = 2, max_length = 124, required = False, placeholder = "Enter username of person to report here.")
        self.add_item(self.emTitle2)

        # Create a long text input and add it to the modal

        self.emDesc1 = nextcord.ui.TextInput(label = "Rules they broke", min_length= 10, max_length = 500, required = True, placeholder = "Write here what the rules this person has broken.", style = nextcord.TextInputStyle.paragraph)
        self.add_item(self.emDesc1)

        self.emDesc2 = nextcord.ui.TextInput(label = "Reason for report", min_length= 50, max_length = 4000, required = True, placeholder = "Enter report reason here.", style = nextcord.TextInputStyle.paragraph)
        self.add_item(self.emDesc2)


    async def callback(self, interaction: nextcord.Interaction) -> None:
        title1 = self.emTitle1.value
        title2 = self.emTitle2.value
        desc1 = self.emDesc1.value
        desc2 = self.emDesc2.value
        em = nextcord.Embed(title="New Report!", description=f"Reported Users Discord: **{title1}**\n\nReported Users Roblox: {title2}\n\n**Rules They Broke:**\n> {desc1}\n\n**Reason For Report:**\n> {desc2}\n\nSubmitter: **{interaction.user.mention}**", timestamp = datetime.now(), color = nextcord.Colour.blurple())
        channel = client.get_channel(1009870106110738472)
        return await channel.send(embed=em)

@client.slash_command(
    name="report",
    description="Report someone in the discord.",
    guild_ids=[serverID],
)
async def report(interaction: nextcord.Interaction):
    modal = Report()
    await interaction.response.send_modal(modal)


class Suggestion(nextcord.ui.Modal):
    def __init__(self):
        super().__init__("Create a Suggestion")  # Modal title

        self.emDesc1 = nextcord.ui.TextInput(label = "Category!", min_length= 1, max_length = 100, required = True, placeholder = "Write Game Suggestion/Server Suggestion.", style = nextcord.TextInputStyle.paragraph)
        self.emDesc2 = nextcord.ui.TextInput(label = "Write your suggestion here!", min_length= 1, max_length = 1000, required = True, placeholder = "Write here what you want your suggestion to be.", style = nextcord.TextInputStyle.paragraph)
        self.add_item(self.emDesc1)
        self.add_item(self.emDesc2)


    async def callback(self, interaction: nextcord.Interaction) -> None:
        desc1 = self.emDesc1.value
        desc2 = self.emDesc2.value
        em = nextcord.Embed(title="New Suggestion!", description=f"**Category:**\n> {desc1}\n\n**Suggestion:**\n> {desc2}\n\n**Submitter:** **{interaction.user.mention}**", timestamp = datetime.now(), color = nextcord.Colour.blurple())
        channel = client.get_channel(974701905882251324)
        message_ = await channel.send(embed=em)
        await message_.add_reaction("👍")
        await message_.add_reaction("👎")
        return


@client.slash_command(
    name="suggestion",
    description="Make a suggestion.",
    guild_ids=[serverID],
)
async def suggestion(interaction: nextcord.Interaction):
    if interaction.channel.id == 805495444285030450 or 974701905882251324:
        modal = Suggestion()
        await interaction.response.send_modal(modal)
    elif interaction.channel.id != 805495444285030450 or 974701905882251324:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'close', description='Use this command to close a Ticket.', guild_ids=[serverID])
async def close(interaction):
    categ=discord.utils.get(interaction.guild.categories,name="Tickets")
    for ch in categ.channels:
        if ch == interaction.channel:
            await interaction.channel.delete()
        else:
            if ch != interaction.channel:
                tickcloseerror = discord.Embed(title=f"**Ticket Error!**", description=f"This is not a Ticket channel.", timestamp=datetime.utcnow(), color=discord.Color.random())
                await interaction.send(embed=tickcloseerror)
                return


@client.slash_command(name = 'open', description=f'Create a new Ticket.', guild_ids=[serverID])
async def new(ctx, reason=None):
    # Ticket Buttons

    button1 = Button(label="Close", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close")
    button2 = Button(label="Confirm", style=discord.ButtonStyle.blurple, emoji="✔️", custom_id="confirm")
    button3 = Button(label="Claim", style=discord.ButtonStyle.green, emoji="🙋‍♂️", custom_id="claim")
    view1 = View(timeout=None)
    view1.add_item(button1)
    view1.add_item(button3)

    view2 = View(timeout=None)
    view2.add_item(button2)
    
    # Confirm close ticket Button

    closeconfirm = discord.Embed(title=f"Close Confirmation", description=f"Please confirm that you want to close this ticket.", color=discord.Color.random())
    async def button_callback1(interaction):
        await channel.send(embed=closeconfirm, view=view2)
        await interaction.response.edit_message(view=view1)


    async def button_callback3(interaction):
        claimticket = discord.Embed(title=f"Claimed Ticket", description=f"Your ticket will be handled by {interaction.user.mention}", color=discord.Color.random())
        nopermission = discord.Embed(title=f"Error", description=f"Only staff members can claim tickets.", color=discord.Color.random())
        if interaction.user.guild_permissions.administrator == True:
            await channel.send(embed=claimticket)
            view1.remove_item(button3)
        else:
            await channel.send(embed=nopermission)
        await interaction.response.edit_message(view=view1)

    # Close Ticket

    async def button_callback2(interaction):
        await channel.delete()


    button1.callback = button_callback1
    button2.callback = button_callback2
    button3.callback = button_callback3

    # Check if a ticket is creatd or not.

    categ=discord.utils.get(ctx.guild.categories,name="Tickets")
    for ch in categ.channels:
        if ch.topic==str(ctx.user.id):
            alreadyopenedticket = discord.Embed(title=f"**Ticket Error!**", description=f"{ctx.user.mention}! You already have a ticket here.\n\n{ch.mention} Click here to go to ticket.", timestamp=datetime.utcnow(), color=discord.Color.random())
            await ctx.send(embed=alreadyopenedticket)
            return

    # Give certain roles access to the ticket.

    r1=ctx.guild.get_role(805518794243964950)

    overwrite={
        ctx.guild.default_role:nextcord.PermissionOverwrite(read_messages=False),
        ctx.user:nextcord.PermissionOverwrite(read_messages=True),
        r1:nextcord.PermissionOverwrite(read_messages=True)
    }

    # Create Ticket

    channel=await categ.create_text_channel(name=f"{ctx.user.name}-{ctx.user.discriminator} ticket",overwrites=overwrite,topic=f"{ctx.user.id}")

    await asyncio.sleep(1)

    # Message that the ticket was created Embed.

    noreasonticketopened = discord.Embed(title=f"**Ticket Created!**", description=f"{channel.mention} Click here to go to ticket.", timestamp=datetime.now(), color=discord.Color.random())
    reasonticketopened = discord.Embed(title=f"**Ticket Created!**", description=f"{channel.mention} Click here to go to ticket.\n\nReason: **{reason}**", timestamp=datetime.now(), color=discord.Color.random())

    noreasonticketview = discord.Embed(title=f"**New Ticket Created!**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())
    reasonticketview = discord.Embed(title=f"**New Ticket Created!** Reason: **{reason}**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())

    # Message that ticket was created.

    if reason is None:
        await ctx.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        await ctx.send(embed=noreasonticketopened)
    else:
        if reason != None:
            await ctx.response.defer(ephemeral = True)
            await asyncio.sleep(0)
            await ctx.send(embed=reasonticketopened)

    if reason is None:
        await channel.send(embed=noreasonticketview, view=view1)
    else:
        if reason != None:
            await channel.send(embed=reasonticketview, view=view1)

            
            
@client.slash_command(name = 'mllink', description='Sends a game link to Merging Legends.', guild_ids=[serverID])
async def mllink(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral = True)
    await asyncio.sleep(1)
    embedVar = discord.Embed(title="**Merging Legends Link**", description="This is a link to the official **Merging Legends** game:\n> https://web.roblox.com/games/5098853904/EVENT-Merging-Legends", color=0xF40357)
    await interaction.send(embed=embedVar)
    
@client.slash_command(name = 'stafflist', description='This shows a list of the Staff Team.', guild_ids=[serverID])
async def stafflist(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral = True)
    await asyncio.sleep(1)
    embedVar = discord.Embed(title="**__Jeremy Studio's Staff List__**", description="These are current staff of **Jeremy's Studios**\n\n**Owner: (1)**\n> <@730858928602087455>\n\n**Manager: (1)**\n> <@299988423421329410>\n\n**Admin: (1)**\n> <@972812238522040321>\n\n> <@234773163781783562>\n\n> <@837458987942281286>\n\n> <@707477110314237974>\n\n> <@672139088647815210>\n\n**Trial Admin: (1)**> <@891071406048157706>", color=0xFF0000)
    await interaction.followup.send(embed=embedVar)

@client.slash_command(name = 'twitter', description='You will receieve a link to the official JS twitter.', guild_ids=[serverID])
async def twitter(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral = True)
    await asyncio.sleep(1)
    embedVar = discord.Embed(title="**Twitter Link**", description="This is the link to the official twitter:\n\n> https://twitter.com/jeremy_studios", color=0xF40357)
    await interaction.followup.send(embed=embedVar)

@client.slash_command(name = 'meme', description='This will send you a meme only you can see.', guild_ids=[serverID])
async def meme(interaction: Interaction):
    if interaction.channel.id == 823291604000702525 or 975462850409685113:
        embed = discord.Embed(title="", description="")

        async with aiohttp.ClientSession() as cs:
            async with cs.get('https://www.reddit.com/r/dankmemes/new.json?sort=hot') as r:
                res = await r.json()
                await interaction.response.defer(ephemeral = False)
                await asyncio.sleep(0)
                embed = discord.Embed(title="**New Meme**", description="Here is a random meme for you", color=0xF40357)
                embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
                await interaction.followup.send(embed=embed)
    elif interaction.channel.id != 823291604000702525 or 975462850409685113:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#823291604000702525>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'shitpost', description='Shows a shitpost.', guild_ids=[serverID])
async def shitpost(interaction: Interaction):
    if interaction.channel.id == 975462850409685113:
        embed = discord.Embed(title="", description="")

        async with aiohttp.ClientSession() as cs:
            async with cs.get('https://www.reddit.com/r/shitposting/new.json?sort=hot') as r:
                res = await r.json()
                await interaction.response.defer(ephemeral = False)
                await asyncio.sleep(0)
                embed = discord.Embed(title="**New Shitpost**", description="Here is a random shitpost for you", color=0xF40357)
                embed.set_image(url=res['data']['children'] [random.randint(0, 25)]['data']['url'])
                await interaction.followup.send(embed=embed)
    elif interaction.channel.id != 975462850409685113:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#975462850409685113>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = '8ball', description='This is a 8ball.', guild_ids=[serverID])
async def eightball(interaction: discord.Interaction, question:str):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        await interaction.followup.send(f"**User:** {question}\n**Response:** {random.choice(responses)}")
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'dadjoke', description='Tells a dad joke.', guild_ids=[serverID])
async def dadjoke(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        await interaction.followup.send(f"Here is a dad joke:\n> **{random.choice(dadjokes)}**")
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@commands.has_permissions(administrator=True)
@client.slash_command(name = 'staffchatrules', description='This shows the Staff Chat Rules.', guild_ids=[serverID])
async def staffchatrules(interaction: discord.Interaction):
    if interaction.user.guild_permissions.view_audit_log == True:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Chat Staff Guidelines**", description="This includes all the information about staff guidelines and what to do in certain situations. (Discord and In-Game)\n\n> **Spam** - Whether intentional or not, you should warn said users 3 times before proceeding to punish them. When punishing on the first offence, mute them for 30 minutes. For further offences, message an Admin or do what you think is right.\n\n> **Harassment/Bullying** - If happened in DMs, you should advise said victim(s) to block the individual. If happened in the server, you should warn the user once to stop, and if carried on, mute them for 1 hour. For further offences, message an Admin or do what you think is right.\n\n> **Threats** If happened in DMs, you should advise said victim(s) to block the individual and can punish said user by kicking them. If happened in the server, depending on the severity of said threat, punishments can range from a 1 hour mute (A simple threat) to a permanent ban (DDoS threats).\n\n> **Racism** - If happened in DMs, you should advise said victim(s) to block the individual and can punish said user by kicking them. If happened in the server, depending on the severity of the racism, punishments may vary from a 1 hour mute (non targetted discrimination) to a permanent ban (slurs).\n\n> **Speaking other languages outside of warranted chat** - Non hard punishable, 3 warnings, after that, a 30 minute mute, and whatever you feel is necessary on further infractions.\n\n> **Sending suspicious/downloadable files in non-designated or designated channels** - 3 warnings, a 1 hour mute after the warnings have been issued, and whatever you feel is necessary on further infractions.\n\n> **Misuse of text channels** - 2 warnings, a 30 minute mute, and whatever you feel on further infractions.\n\n> **Advertising** - If happened in DMs, you should advise said victim(s) to block the individual, additionally you may permanently ban said user for DM advertising after 1 previous warning. If happened in server, you should permanently ban the user without warning.\n\n> **Excessive Swearing** - You should warn the user to stop twice, before muting them for 1 hour or above. Further infractions are up to the moderator.\n\n> **Unnecessarily pinging issues** - You should warn the user twice to stop, before muting them for 30 minutes to an hour. Further infractions are up to the moderator.\n\n> **NSFW/Dirty mind content** - You should mute them for 30 minutes on the first infraction, and whatever you feel is necessary depending on severity for further infractions.\n\n> **Troll Suggestions** - You should delete the user's troll suggestion, and if you can, message them to not do it again.\n\n> **Talking about sensitive topics** - You should warn them to stop, and once they have more than 2 warns, mute them for 30 minutes. For further infractions, the admin will decide.", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
    else:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="Error!", description=(f'You do not have a permission to issue this command.'), color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)


@commands.has_permissions(administrator=True)
@client.slash_command(name = 'staffvoicerules', description='This shows the Staff Voice Rules.', guild_ids=[serverID])
async def staffvoicerules(interaction: discord.Interaction):
    if interaction.user.guild_permissions.view_audit_log == True:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Voice Chat Staff Guidelines**", description="> **Using voice changers to cause annoyance** - You should mute the user until they decide to stop.\n\n> **Playing earrape music/sounds** - You should immediately disconnect the user, and server deafen them. It will also result in a warning to the user.\n\n> **Playing random music when others are trying to talk** - The bot should be disconnected from the channel, as well as the user that is abusing it.", color=0xDC0000)
        await interaction.followup.send(embed=embedVar)
    else:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="Error!", description=(f'You do not have a permission to issue this command.'), color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)


@commands.has_permissions(administrator=True)
@client.slash_command(name = 'staffmiscrules', description='This shows the Staff Miscellaneous Rules.', guild_ids=[serverID])
async def staffvoicerules(interaction: discord.Interaction):
    if interaction.user.guild_permissions.view_audit_log == True:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Miscellaneous Staff Guidelines**", description="> **Fighting in public channels** - You should warn the user(s) to stop fighting, and if they didn't, you should mute them both for 30 minutes.\n\n> **Spreading fake news/chain mail** - You should delete the person's message, and warn them to stop preferably via DMs.\n\n> **Ban/Mute Evasion** - This includes rejoining to reset roles/timeout, creating alts, etc. The user should immediately be quarantined if possible, and if not, the user should be kicked/banned depending on the severity.\n\n> **Intentional staff/user impersonation** - You should change the nickname of the user, and tell them to change their profile picture. They will receive a warning. On the next offence, they will be kicked from the Discord.\n\n> **Bribery of staff out of punishment** - It will lead to an extension of said punishment by 1 hour, depending on severity, you may increase from 1 hour to 10 hours max.\n\n> **Attempting to mass-ping or ping certain roles** - It will lead to you being warned, and on further infractions muted for 30 minutes, and whatever the admin decides next.\n\n> **Mini Modding** - If someone is caught mini modding, you will give the person that was mini modding a warn, and if they continue to mini mod after the warn they will recieve a mute that you think has a fitting length.", color=0xE5F403)
        await interaction.followup.send(embed=embedVar)
    else:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="Error!", description=(f'You do not have a permission to issue this command.'), color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)

@commands.has_permissions(administrator=True)
@client.slash_command(name = 'staffsyntaxrules', description='This shows the Staff Syntax & Information.', guild_ids=[serverID])
async def staffsyntaxrules(interaction: discord.Interaction):
    if interaction.user.guild_permissions.view_audit_log == True:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Command Syntax & More Information**", description="> **Warn Syntax:** - w!warn <user> ?r <reason>\n> **Example:** w!warn @DarkStars ?r Spam\n> **Explenation:** Warns a user.\n\n> **Mute/Timeout Syntax** - w!mute <user> <time> ?r <reason>\n> **Example:** w!mute @DarkStars 1h ?r Spam\n> **Explenation:** Removes the user's ability to talk for a specificed amount of time.\n\n> **Kick Syntax** - w!kick @DarkStars ?r <reason>\n> **Example:** w!kick @DarkStars ?r Spam\n> **Explenation:** Kicks the user from the Discord Server.\n\n> **Ban Syntax** - w!ban <user> <time/none for permanent> ?r <reason>\n> **Permanent Example:** w!ban @DarkStars ?r Cheating\n> **Normal Example:** w!ban @DarkStars 3d ?r Cheating\n> **Explenation:** Bans the player from the Discord server, making it so they cannot rejoin.\n\n> **Quarantine Syntax** - w!quarantine @DarkStars ?r <reason>\n\n> **Example:** w!quarantine @DarkStars ?r Suspicious Activity\n\n> **Explenation:** Removes the user's ability to talk or see any channels.\n\n**For offences not listed, please punish accordingly, to whatever you think is responsible.**", color=0x36F403)
        await interaction.followup.send(embed=embedVar)
    else:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="Error!", description=(f'You do not have a permission to issue this command.'), color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)

@commands.has_permissions(administrator=True)
@client.slash_command(name = 'codes', description='This shows the Merging Legends Codes.', guild_ids=[serverID])
async def codes(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**__Merging Legends Codes__**", description="These are the codes for **Merging Legends**\n\n**__Working Codes:__**\n> **Circle** - 10 BG Circles and 20 Magnets.\n\n> **Circle++** - 100 Golden Circles and 200 Mangets.\n\n> **SuperMergeQuest** - 3 Merge Tokens\n\n> **ClicksForU** - x1,024 Clicks/Click\n\n> **FreeDiamond** - 50 Diamond Circles.\n\n> **FreeEmerald** - 5 Emerald Circles.\n\n**__Expired Codes:__**\n> **5MillionVisits** - 100 Diamond Circles.\n\n> **6MillionVisits** - 10 Emerald Circles.\n\n> **25kLikes** - 10 Emerald Circles\n\n> **7MillionVisits** - 10 Emerald Circles *[Expired May 28, 2022 | 12:00 AM]*\n\n> **2YearsMergingLegends** - 10 Emerald Circles *[Expired Jun 18, 2022 | 12:00 PM UTC]*\n\n> **30kLikes** - 10 Emerald Circles *[Expires Jul 10, 2022 | 12:00 PM UTC]\n\n> **9MillionVisits** - 100 Diamond Circles *[Expires Jul 30, 2020 12:00 PM (UTC)]*", color=0xB60B9C)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'chatrules', description='This shows the rules for when you chat.', guild_ids=[serverID])
async def chatrules(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Chat Rules**", description="This includes all the rules based on text channels\n\n> **1)** Don't spam, no matter what channel you're in. This includes emojis, text, images, videos, gifs, files.\n\n> **2)** Don't harass anyone, in DMs or the server.\n\n> **3)** Don't bully people, in DMs or the server.\n\n> **4)** No threats, these include death threats, dox/DDoS threats.\n\n> **5)** No racism, even if it's just 'a joke'.\n\n> **6)** Please refrain from speaking languages other than English in main channels.\n\n> **7)** Do not send downloadable files.\n\n> **8)** Use the right channels for the right reasons.\n\n> **9)** Please refrain from talking about sensitive topics such as religions, drugs and politics.\n\n> **10)** Do not advertise, whether it is in DMs or the server.\n\n> **11)** Do not unnecessarily ping anyone, whether they're staff or just any user.\n\n> **12** Don't swear directly at someone and try to keep the swearing light if possible.\n\n> **13)** Please refrain from quacking in any channel.\n\n> **14** Do not bypass filters. \n\n> **15** Respect all members and staff.\n\n> **16)** No NSFW content.\n\n> **17)** No Favoritism (Staff)", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'voicerules', description='This shows the rules for when you are in voice chat.', guild_ids=[serverID])
async def voicerules(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Voice Chat Rules**", description="This includes all the rules based on voice channels\n\n> **1)** Do not use voice changers unless all people in the voice chat agree.\n\n> **2)** Don't play loud music or earrape in voice chats.\n\n> **3)** Don't play random music in a voice chat that people are using to chat.\n\n> **4)** No microphone spamming, microphone checking users, join/leave spamming.", color=0xF40303)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'miscrules', description='This shows the rules for miscellaneous.', guild_ids=[serverID])
async def miscrules(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Miscellaneous  Rules**", description="This includes the other rules, which don't necessarily fit in any other category.\n\n> **1)** Please keep fights in DM rather than over our text/voice chats.\n\n> **2)** No spreading fake news, mindless copypasta or chainmail.\n\n> **3)** No evading bans/mutes (This includes leaving and rejoining to reset roles).\n\n> **4)** No intentional staff or user impersonation.\n\n> **5)** Do not attempt to bribe any staff members out of punishment.\n\n> **6)** Staff decisions are final. Please refrain from talking back to them.\n\n> **7)** Please do not submit troll suggestions.\n\n> **8)** Please refrain from attempting to ping everyone or mass-ping.\n\n> **9)** Please refrain from mini modding in any chat, that is the staff's job.", color=0x03F412)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'note', description='This shows an important note.', guild_ids=[serverID])
async def gnote(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Note**", description="**Violation of any of our rules or the Discord Terms of Service (Found here: https://discord.com/terms) Will result in immediate punishment such as warn, mute, kick or ban if necessary. Staff always have the final word in punishments. If you feel that a staff is stepping over the line or abusing, please contact <@730858928602087455> or <@299988423421329410> immediately.**\n\n**Members always have the right to report a staff member, no matter what.**", color=0xA003F4)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return
    
@client.slash_command(name = 'about', description='This tells you about the bot.', guild_ids=[serverID])
async def about(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**About**", description="The **Jeremy Studio's** Utility Bot\n\n**Bot Creation Date:**\n> ***6/28/22 21:31PM UTC+1***\n\n**Bot Creators:**\n> <@299988423421329410> & <@972812238522040321>\n\n**Bot Purpose:**\n> The main purpose of the bot is to be able to **Utilities** the community and show all the necessary information.\n\n**For More Information:**\n> Use the command: **/help**", color=0xA003F4)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'faq', description='This shows the Frequently Asked Questions.', guild_ids=[serverID])
async def faq(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Merging Legends Information Channel**", description="This channel will provide all the information you will need to know about this Discord server!\n\n**FAQ**\n__How Do I Get Emerald Circles?__\n> There are 3 ways to acquire Emerald Circles. You can either buy them using Robux, wait for them to spawn in the spheres area or use special codes!\n\n__How Do I Unlock Other Map Areas?__\n> You will unlock the other map areas the further you progress in the game. You will unlock the cubes area at 15 super spheres, the wedges area at 200 cubes, and the trusses area at 500 wedges.\n\n__What Does The Secret Chest Do?__\n> At the moment, the secret chest does nothing. It's just a little easter egg\n\n__How Do I Auto Merge Faster?__\n> You can upgrade your auto merge speed by upgrading the magnet upgrade, upgrading it in the solar system, or the 3rd row of tire upgrades!\n\n__Are Macros/Autoclickers allowed?__\n> You may use macros and autoclickers in Merging Legends, but please refrain from using exploits (scripts)", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'csinfo', description='This shows the circle submission information.', guild_ids=[serverID])
async def csinfo(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Circle Submission Info**", description="This includes everything you need to know to start submitting circles!\n\n> Circles must be 750x750 pixels when you submit one\n> You must wait 30 minutes between submitting circles\n> They must be submitted in a circle shape\n> They must have a transparent background\n> The image must be a .png format\n> The circle has to be your design, meaning you cannot copy another circle You cannot submit circles for other people\n> You may not collaborate with others to make a circle\n> You cannot take images from google or websites and put it in your circle, unless it is a small part of your circle and a non-copyrighted image\n> Must use one of the circle bases below\n> You must put the circle name and your username when you submit one\n\n**Please abide by these guidelines at all times when submitting circles.**\n\n You may use any of the following circle bases for your design (click links to instantly download):\nhttps://i.imgur.com/uRAQoYM.jpg\n\nhttps://i.imgur.com/thqlWtA.png\n\n**You can remove the background of your circles using** <https://remove.bg/upload>**, or you can do it directly in your photo editing app.**", color=0xF40303)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'rankinfo', description='This shows the how to get certain ranks.', guild_ids=[serverID])
async def rankinfo(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        embedVar = discord.Embed(title="**Rank Information**", description="This includes everything you need to know about acquirable ranks!\n\n**Circle Ranks**\n__60 Circles Accepted__\n<@&1005479100976205926>\n\n__30 Circles Accepted__\n> <@&975027098433503232>, tag in-game\n\n__20 Circles Accepted__\n> <@&975026942841602108> Role, tag in-game\n\n__10 Circles Accepted__\n> <@&974953804225204234>  Role, tag in-game\n\n__4 Circles Accepted__\n> <@&974953549391888454>  Role, tag in-game\n\n**Suggestor Ranks**\n__50 Suggestions Accepted__\n> <@&975023483211878460> Role\n\n__25 Suggestions Accepted__\n> <@&975023196006928394> Role\n\n__10 Suggestions Accepted__\n> <@&974966213413306418> Role\n\n__5 Suggestions Accepted__\n> <@&974965986430165022> Role\n\n**Activity Ranks**\n__Level 35 (Arcane)__\n> <@&977865507980075098> Role\n\n__Level 25 (Arcane)__\n> <@&977865412836466698> Role\n\n__Level 10 (Arcane)__\n> <@&977865227502755851> Role", color=0x28F403)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'ticketinfo', description='This shows the information on how to open a ticket.', guild_ids=[serverID])
async def ticketinfo(interaction: discord.Interaction):
    if interaction.channel.id == 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(1)
        channel = client.get_channel(805495444285030450)  
        embedVar = discord.Embed(title="**Ticket Information**", description="This includes everything you need to know about how to open a ticket!\n\n**You can make a new ticket by executing** $open **in** <#805495444285030450>\n\n**Please do not repetitively make tickets, we will get back to you as fast as we can. Joke/troll tickets will be deleted. If you abuse tickets, you risk being blacklisted from creating tickets in the future.**", color=0x9C03F4)
        await interaction.followup.send(embed=embedVar)
    elif interaction.channel.id != 805495444285030450:
        await interaction.response.defer(ephemeral = True)
        await asyncio.sleep(0)
        embedVar = discord.Embed(title="**Error**", description="You can't use that command in this channel.\n\n> Please go to <#805495444285030450>", color=0x00B6FF)
        await interaction.followup.send(embed=embedVar)
        return

@client.slash_command(name = 'commands', description='This shows a list of all the commands.', guild_ids=[serverID])
async def commands(interaction: nextcord.Interaction):
    await asyncio.sleep(1)
    commandsEmbed = nextcord.Embed(title="Commands List", description="This displays all avaiable commands in Jeremy Studios.", color=0xF40357)
    commandsEmbed.add_field(name="/codes", value="Shows the codes in **Merging Legends**", inline=True)
    commandsEmbed.add_field(name="/stafflist", value="Shows the list of the staff team for members.", inline=True)
    commandsEmbed.add_field(name="/mllink", value="Shows a link to **Merging Legends**.", inline=True)
    commandsEmbed.add_field(name="/8ball", value="Ask the 8Ball a question.", inline=True)
    commandsEmbed.add_field(name="/dadjoke", value="Tells you a random dad joke.", inline=True)
    commandsEmbed.add_field(name="/meme", value="Shows you a random meme.", inline=True)
    commandsEmbed.add_field(name="/twitter", value="Shows a link to the official **JS** twitter.", inline=True)
    commandsEmbed.add_field(name="/faq", value="Shows a list of the FAQ.", inline=True)
    commandsEmbed.add_field(name="/csinfo", value="Shows Circle Submission Info.", inline=True)
    commandsEmbed.add_field(name="/rankinfo", value="Shows a list of the Rank Information.", inline=True)
    commandsEmbed.add_field(name="/ticketinfo", value="Shows a list of the Ticket Info.", inline=True)
    commandsEmbed.add_field(name="/chatules", value="Shows a list of the Chat Rules.", inline=True)
    commandsEmbed.add_field(name="/voicerules", value="Shows a list of the Voice Rules.", inline=True)
    commandsEmbed.add_field(name="/miscrules", value="This shows the miscs.", inline=True)
    commandsEmbed.add_field(name="/note", value="This shows an important note for members.", inline=True)
    commandsEmbed.add_field(name="/about", value="This will tell you information about the bot.", inline=True)
    commandsEmbed.add_field(name="/shitpost", value="This will show you a random shitpost.", inline=True)
    commandsEmbed.add_field(name="/open", value="This command lets you open a ticket to get assited by staff.", inline=True)
    commandsEmbed.add_field(name="/report", value="This command will let you report a member in the discord.", inline=True)
    commandsEmbed.add_field(name="/commands", value="Shows this list.", inline=True)
    await interaction.followup.send(embed=commandsEmbed, ephemeral=True)

@client.event
async def on_message(message: discord.Message):
    if message.guild is None and not message.author.bot:
        print(f'{message.author.name}: {message.content}')
        interaction = Interaction
        time = message.author.created_at
        difference = time - round(time.time() * 1000)

        print(difference)
    else:
        await client.process_commands(message)

client.run('OTkxNDM1OTE5MzIyMjU1NDQx.GZVNoA.mR39NTpfeNhw-ah2AzIHs0ui7ab9kp_yKUDaGo')
