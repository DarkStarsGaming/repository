from http import server
from optparse import Option
import discord, datetime
from discord.ui import Button, View, Select
from discord.ext.commands import has_permissions, MissingPermissions, bot
from discord.ext import commands
from discord.ext.commands import MissingPermissions
import discord, datetime
from discord.ext.commands import Bot
from discord.ext import commands
import random
import nextcord, datetime
import os
from nextcord import Interaction, SlashOption, ChannelType, User
from datetime import datetime
from nextcord.abc import GuildChannel
from nextcord.ext import commands
from nextcord.ui import Select, View, Button
import asyncio
from requests import get
import aiohttp
import io


client = commands.Bot(command_prefix = "!")

serverID = 805379039924846613

@client.event
async def on_ready():
    print('Connected to bot: {}'.format(client.user.name))
    print('Bot ID: {}'.format(client.user.id))


@client.slash_command(name = 'close', description='Use this command to close a Ticket.', guild_ids=[serverID])
async def close(interaction):
    categ=discord.utils.get(interaction.guild.categories,name="Tickets")
    for ch in categ.channels:
        if ch == interaction.channel:
            await interaction.channel.delete()
        else:
            if ch != interaction.channel:
                tickcloseerror = discord.Embed(title=f"**Ticket Error!**", description=f"This is not a Ticket channel.", timestamp=datetime.utcnow(), color=discord.Color.random())
                await interaction.send(embed=tickcloseerror)
                return


@client.slash_command(name = 'open', description=f'Create a new Ticket.', guild_ids=[serverID])
async def new(ctx, reason=None):
    # Ticket Buttons

    button1 = Button(label="Close", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close")
    button2 = Button(label="Confirm", style=discord.ButtonStyle.blurple, emoji="✔️", custom_id="confirm")
    button3 = Button(label="Claim", style=discord.ButtonStyle.green, emoji="🙋‍♂️", custom_id="claim")
    button4 = Button(label="Close With Reason", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="closewithreason")
    view1 = View(timeout=None)
    view1.add_item(button1)
    view1.add_item(button4)
    view1.add_item(button3)

    view2 = View(timeout=None)
    view2.add_item(button2)


    openedby = ctx.user.mention
    channeltimeopened = timestamp=datetime.now()
    
    # Confirm close ticket Button

    closeconfirm = discord.Embed(title=f"Close Confirmation", description=f"Please confirm that you want to close this ticket.", color=discord.Color.random())
    async def button_callback1(interaction):
        await channel.send(embed=closeconfirm, view=view2)
        await interaction.response.edit_message(view=view1)


    async def button_callback3(interaction):
        claimticket = discord.Embed(title=f"Claimed Ticket", description=f"Your ticket will be handled by {interaction.user.mention}", color=discord.Color.random())
        nopermission = discord.Embed(title=f"Error", description=f"Only staff members can claim tickets.", color=discord.Color.random())
        if interaction.user.guild_permissions.administrator == True:
            await channel.send(embed=claimticket)
            global ticketclaimedby
            ticketclaimedby = interaction.user.id
            view1.remove_item(button3)
        else:
            await channel.send(embed=nopermission)
        await interaction.response.edit_message(view=view1)

    # Close Ticket

    async def button_callback2(interaction):
        ticketname = channel.name
        closeticketembed = nextcord.Embed(title="Ticket Closed", timestamp = datetime.now(), color = nextcord.Colour.blurple())
        closeticketembed.add_field(name="Ticket name", value=f"{ticketname}", inline=True)
        closeticketembed.add_field(name="Opened By", value=f"{openedby}", inline=True)
        closeticketembed.add_field(name="Closed By", value=f"{interaction.user.mention}", inline=True)
        closeticketembed.add_field(name="Reason", value=f"Reason not specified", inline=False)
        closeticketembed.add_field(name="Open Time", value=f"{channeltimeopened}", inline=True)
        closeticketembed.add_field(name="Claimed By", value=f"<@{ticketclaimedby}>", inline=True)
        await channel.delete()
        ticketlogchannel = client.get_channel(1010292847972470874)
        await ticketlogchannel.send(embed=closeticketembed)


    button1.callback = button_callback1
    button2.callback = button_callback2
    button3.callback = button_callback3

    # Check if a ticket is creatd or not.

    categ=discord.utils.get(ctx.guild.categories,name="Tickets")
    for ch in categ.channels:
        if ch.topic==str(ctx.user.id):
            alreadyopenedticket = discord.Embed(title=f"**Ticket Error!**", description=f"{ctx.user.mention}! You already have a ticket here.\n\n{ch.mention} Click here to go to ticket.", timestamp=datetime.utcnow(), color=discord.Color.random())
            await ctx.send(embed=alreadyopenedticket)
            return

    # Give certain roles access to the ticket.

    r1=ctx.guild.get_role(805518794243964950)

    overwrite={
        ctx.guild.default_role:nextcord.PermissionOverwrite(read_messages=False),
        ctx.user:nextcord.PermissionOverwrite(read_messages=True),
        r1:nextcord.PermissionOverwrite(read_messages=True)
    }

    # Create Ticket

    channel=await categ.create_text_channel(name=f"{ctx.user.name}-{ctx.user.discriminator} ticket",overwrites=overwrite,topic=f"{ctx.user.id}")

    await asyncio.sleep(1)

    # Message that the ticket was created Embed.

    noreasonticketopened = discord.Embed(title=f"**Ticket Created!**", description=f"{channel.mention} Click here to go to ticket.", timestamp=datetime.now(), color=discord.Color.random())
    reasonticketopened = embedVar = discord.Embed(title=f"**Ticket Created!**", description=f"{channel.mention} Click here to go to ticket.\n\nReason: **{reason}**", timestamp=datetime.now(), color=discord.Color.random())

    noreasonticketview = discord.Embed(title=f"**New Ticket Created!**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())
    reasonticketview = discord.Embed(title=f"**New Ticket Created!** Reason: **{reason}**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())

    # Message that ticket was created.

    if reason is None:
        await ctx.send(embed=noreasonticketopened)
    else:
        if reason != None:
            embedVar = discord.Embed(title=f"**Ticket Created!**", description=f"{channel.mention} Click to go to ticket.\n\nReason: **{reason}**", timestamp=datetime.now(), color=discord.Color.random())
            await ctx.send(embed=reasonticketopened)

    if reason is None:
        embedVar = discord.Embed(title=f"**New Ticket Created!**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())
        await channel.send(embed=noreasonticketview, view=view1)
    else:
        if reason != None:
            embedVar = discord.Embed(title=f"**New Ticket Created!** Reason: **{reason}**", description=f"Ticket created by {ctx.user.mention}", timestamp=datetime.now(), color=discord.Color.random())
            await channel.send(embed=reasonticketview, view=view1)



client.run('OTkxNDM1OTE5MzIyMjU1NDQx.GZVNoA.mR39NTpfeNhw-ah2AzIHs0ui7ab9kp_yKUDaGo')
